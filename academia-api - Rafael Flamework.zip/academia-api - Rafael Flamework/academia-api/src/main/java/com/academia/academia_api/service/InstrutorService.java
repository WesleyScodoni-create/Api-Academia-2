package com.academia.service;

import com.academia.model.Instrutor;
import com.academia.repository.InstrutorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class InstrutorService {

    @Autowired
    private InstrutorRepository repository;

    public List<Instrutor> listarTodos() {
        return repository.findAll();
    }

    public List<Instrutor> listarAtivos() {
        return repository.findByAtivoTrue();
    }

    public Optional<Instrutor> buscarPorId(Long id) {
        return repository.findById(id);
    }

    public Instrutor criar(Instrutor instrutor) {
        return repository.save(instrutor);
    }

    public Instrutor atualizar(Long id, Instrutor instrutorAtualizado) {
        return repository.findById(id)
                .map(instrutor -> {
                    instrutor.setNome(instrutorAtualizado.getNome());
                    instrutor.setCpf(instrutorAtualizado.getCpf());
                    instrutor.setTelefone(instrutorAtualizado.getTelefone());
                    instrutor.setEmail(instrutorAtualizado.getEmail());
                    instrutor.setEspecialidade(instrutorAtualizado.getEspecialidade());
                    instrutor.setSalario(instrutorAtualizado.getSalario());
                    instrutor.setDataContratacao(instrutorAtualizado.getDataContratacao());
                    instrutor.setAtivo(instrutorAtualizado.getAtivo());
                    return repository.save(instrutor);
                })
                .orElseThrow(() -> new RuntimeException("Instrutor não encontrado"));
    }

    public void deletar(Long id) {
        if (!repository.existsById(id)) {
            throw new RuntimeException("Instrutor não encontrado");
        }
        repository.deleteById(id);
    }
}
