package com.academia.service;

import com.academia.model.Plano;
import com.academia.repository.PlanoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class PlanoService {

    @Autowired
    private PlanoRepository repository;

    public List<Plano> listarTodos() {
        return repository.findAll();
    }

    public List<Plano> listarAtivos() {
        return repository.findByAtivoTrue();
    }

    public Optional<Plano> buscarPorId(Long id) {
        return repository.findById(id);
    }

    public Plano criar(Plano plano) {
        return repository.save(plano);
    }

    public Plano atualizar(Long id, Plano planoAtualizado) {
        return repository.findById(id)
                .map(plano -> {
                    plano.setNome(planoAtualizado.getNome());
                    plano.setDescricao(planoAtualizado.getDescricao());
                    plano.setValorMensal(planoAtualizado.getValorMensal());
                    plano.setDuracaoMeses(planoAtualizado.getDuracaoMeses());
                    plano.setAtivo(planoAtualizado.getAtivo());
                    return repository.save(plano);
                })
                .orElseThrow(() -> new RuntimeException("Plano não encontrado"));
    }

    public void deletar(Long id) {
        if (!repository.existsById(id)) {
            throw new RuntimeException("Plano não encontrado");
        }
        repository.deleteById(id);
    }
}
