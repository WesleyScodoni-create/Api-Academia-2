package com.academia.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "planos")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Plano {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idPlano;

    @NotBlank(message = "Nome do plano é obrigatório")
    @Size(min = 3, max = 100)
    private String nome;

    @Column(columnDefinition = "TEXT")
    private String descricao;

    @NotNull(message = "Valor mensal é obrigatório")
    @DecimalMin(value = "0.0", message = "Valor deve ser positivo")
    private Double valorMensal;

    @NotNull(message = "Duração é obrigatória")
    @Min(value = 0, message = "Duração mínima: 0 meses")
    private Integer duracaoMeses;

    private Boolean ativo = true;

    private LocalDateTime dataCriacao = LocalDateTime.now();
}