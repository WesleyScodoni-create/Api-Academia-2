package com.academia.repository;

import com.academia.model.Instrutor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface InstrutorRepository extends JpaRepository<Instrutor, Long> {
    List<Instrutor> findByAtivoTrue();
    List<Instrutor> findByEspecialidade(String especialidade);
}
