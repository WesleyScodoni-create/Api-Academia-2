package com.academia.service;

import com.academia.model.Aluno;
import com.academia.repository.AlunoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class AlunoService {

    @Autowired
    private AlunoRepository repository;

    public List<Aluno> listarTodos() {
        return repository.findAll();
    }

    public List<Aluno> listarAtivos() {
        return repository.findByAtivoTrue();
    }

    public Optional<Aluno> buscarPorId(Long id) {
        return repository.findById(id);
    }

    public Aluno criar(Aluno aluno) {
        validarCpfUnico(aluno.getCpf(), null);
        validarEmailUnico(aluno.getEmail(), null);
        return repository.save(aluno);
    }

    public Aluno atualizar(Long id, Aluno alunoAtualizado) {
        return repository.findById(id)
                .map(aluno -> {
                    validarCpfUnico(alunoAtualizado.getCpf(), id);
                    validarEmailUnico(alunoAtualizado.getEmail(), id);

                    aluno.setNome(alunoAtualizado.getNome());
                    aluno.setCpf(alunoAtualizado.getCpf());
                    aluno.setDataNascimento(alunoAtualizado.getDataNascimento());
                    aluno.setTelefone(alunoAtualizado.getTelefone());
                    aluno.setEmail(alunoAtualizado.getEmail());
                    aluno.setEndereco(alunoAtualizado.getEndereco());
                    aluno.setPeso(alunoAtualizado.getPeso());
                    aluno.setAltura(alunoAtualizado.getAltura());
                    aluno.setAtivo(alunoAtualizado.getAtivo());

                    return repository.save(aluno);
                })
                .orElseThrow(() -> new RuntimeException("Aluno não encontrado"));
    }

    public void deletar(Long id) {
        if (!repository.existsById(id)) {
            throw new RuntimeException("Aluno não encontrado");
        }
        repository.deleteById(id);
    }

    private void validarCpfUnico(String cpf, Long idExcluir) {
        Optional<Aluno> alunoExistente = repository.findByCpf(cpf);
        if (alunoExistente.isPresent() && !alunoExistente.get().getIdAluno().equals(idExcluir)) {
            throw new RuntimeException("CPF já cadastrado");
        }
    }

    private void validarEmailUnico(String email, Long idExcluir) {
        Optional<Aluno> alunoExistente = repository.findByEmail(email);
        if (alunoExistente.isPresent() && !alunoExistente.get().getIdAluno().equals(idExcluir)) {
            throw new RuntimeException("Email já cadastrado");
        }
    }
}