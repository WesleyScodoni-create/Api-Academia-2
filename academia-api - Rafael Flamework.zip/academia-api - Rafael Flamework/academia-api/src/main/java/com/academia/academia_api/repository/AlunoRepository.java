package com.academia.repository;

import com.academia.model.Aluno;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface AlunoRepository extends JpaRepository<Aluno, Long> {
    List<Aluno> findByAtivoTrue();
    Optional<Aluno> findByCpf(String cpf);
    Optional<Aluno> findByEmail(String email);
    List<Aluno> findByNomeContainingIgnoreCase(String nome);
}